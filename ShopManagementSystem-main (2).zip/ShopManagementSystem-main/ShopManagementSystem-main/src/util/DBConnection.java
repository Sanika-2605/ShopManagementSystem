package util;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Legacy database connection class for backward compatibility.
 * New code should use DatabaseManager instead.
 */
@Deprecated
public class DBConnection {
    
    /**
     * Gets a database connection.
     * @return A database connection
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return DatabaseManager.getConnection();
    }
    
    /**
     * Checks if a connection is valid (for backward compatibility).
     * @param connection the connection to check
     * @return true if the connection is valid
     */
    public static boolean isConnectionValid(Connection connection) {
        try {
            return connection != null && !connection.isClosed() && connection.isValid(5);
        } catch (SQLException e) {
            return false;
        }
    }
    
    /**
     * Returns a connection to the pool (for backward compatibility).
     * In this simple implementation, we just close the connection.
     * @param connection the connection to return
     */
    public static void returnConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                // Ignore
            }
        }
    }
}