package util;

import java.sql.Connection;
import java.sql.SQLException;
import java.io.InputStream;
import java.util.Properties;
import java.io.IOException;

public class DatabaseManager {
    private static String URL;
    private static String USER;
    private static String PASSWORD;
    
    static {
        loadDatabaseProperties();
    }
    
    private static void loadDatabaseProperties() {
        try (InputStream input = DatabaseManager.class.getClassLoader().getResourceAsStream("config/db.properties")) {
            Properties prop = new Properties();
            if (input == null) {
                System.err.println("Unable to find db.properties file");
                // Fallback to hardcoded values
                URL = "jdbc:mysql://localhost:3306/shopdb";
                USER = "root";
                PASSWORD = "sanika%$#@123";
                return;
            }
            prop.load(input);
            URL = prop.getProperty("db.url");
            USER = prop.getProperty("db.username");
            PASSWORD = prop.getProperty("db.password");
        } catch (IOException ex) {
            ex.printStackTrace();
            // Fallback to hardcoded values
            URL = "jdbc:mysql://localhost:3306/shopdb";
            USER = "root";
            PASSWORD = "sanika%$#@123";
        }
    }

    public static Connection getConnection() throws SQLException {
        return java.sql.DriverManager.getConnection(URL, USER, PASSWORD);
    }
}