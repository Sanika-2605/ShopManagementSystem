package ui;
import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    public DashboardFrame(String role, int userId) {
        setTitle("Dashboard - " + role);
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        tabs.add("Products", new ProductPanel());
        tabs.add("Customers", new Customer());
        tabs.add("Billing", new BillingPanel(userId)); // Pass user ID to BillingPanel
        if(role.equalsIgnoreCase("ADMIN")) tabs.add("Users", new UserPanel());

        add(tabs);
    }
}