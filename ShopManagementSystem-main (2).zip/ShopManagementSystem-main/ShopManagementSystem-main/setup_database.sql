-- Create the shopdb database
CREATE DATABASE IF NOT EXISTS shopdb;
USE shopdb;

-- Create the products table
CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL DEFAULT 0
);

-- Create the customers table
CREATE TABLE IF NOT EXISTS customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20)
);

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'CASHIER') NOT NULL
);

-- Create the bills table
CREATE TABLE IF NOT EXISTS bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    user_id INT NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    bill_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create the bill_items table
CREATE TABLE IF NOT EXISTS bill_items (
    bill_item_id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Insert a default admin user (password is 'admin123' hashed with SHA256)
INSERT INTO users (username, password_hash, role) 
SELECT 'admin', '6005105581924819375012175199900907607568061020703693193435854224374221003064376444112133', 'ADMIN'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');

-- Insert sample products
INSERT INTO products (name, price, quantity) 
SELECT 'Sample Product 1', 10.50, 100
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Sample Product 1');

INSERT INTO products (name, price, quantity) 
SELECT 'Sample Product 2', 25.99, 50
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Sample Product 2');

-- Insert sample customers
INSERT INTO customers (name, phone) 
SELECT 'John Doe', '123-456-7890'
WHERE NOT EXISTS (SELECT 1 FROM customers WHERE name = 'John Doe');

INSERT INTO customers (name, phone) 
SELECT 'Jane Smith', '098-765-4321'
WHERE NOT EXISTS (SELECT 1 FROM customers WHERE name = 'Jane Smith');